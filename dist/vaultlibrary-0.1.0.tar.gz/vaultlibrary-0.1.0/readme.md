# asc-models

Shared, versioned models for Python services.  
**v0.1.0** currently exposes the `Caller` enum.

## Install
```bash
pip install asc-models
