from src.vaultModels.enums import Caller

def test_values():
    assert Caller.MANDI_ON_MOBILE == 100
    assert Caller.UNKNOWN == 700
